# =============================================================================
# utils/__init__.py — Public API for Chapter 15 Utility Package
# Chapter 15: Education and Knowledge Agents
# Book: 30 Agents Every AI Engineer Must Build (Packt Publishing)
# Author: Imran Ahmad
#
# Exports:
#   MockLLM            — Simulation-mode LLM with section-mapped responses (§6)
#   ColorLogger        — Color-coded execution tracing (§4)
#   LogLevel           — ANSI color enum for log levels (§4)
#   graceful_fallback  — Exception-safe decorator with mock routing (§5)
# =============================================================================

from utils.resilience import ColorLogger, LogLevel, graceful_fallback
from utils.mock_llm import MockLLM

__all__ = [
    "MockLLM",
    "ColorLogger",
    "LogLevel",
    "graceful_fallback",
]
