# Troubleshooting Guide
## Chapter 15: Education and Knowledge Agents

> From *30 Agents Every AI Engineer Must Build* by Imran Ahmad (Packt Publishing)

---

## 1. Dependency Conflicts

| Symptom | Root Cause | Resolution |
|---|---|---|
| `pip's dependency resolver` error on `openai` | Conflicting `httpx`/`pydantic` versions | Isolated venv: `python -m venv ch15env && source ch15env/bin/activate && pip install -r requirements.txt` |
| `ImportError: cannot import name 'OpenAI'` | Old `openai` SDK (pre-1.0) installed | `pip install --force-reinstall openai==1.40.0` |
| `numpy` build fails on Apple Silicon | Missing `accelerate` framework | `pip install numpy==1.26.4 --only-binary=:all:` or use conda |
| `networkx` import OK but `get_dependents()` missing | `networkx<3.0` has different API | Verify: `python -c "import networkx; print(networkx.__version__)"` → must be `3.3` |
| `ModuleNotFoundError: No module named 'dotenv'` | Package name mismatch | `pip install python-dotenv==1.0.1` (not `pip install dotenv`) |
| Kernel dies on first cell | Kernel not linked to venv | `python -m ipykernel install --user --name=ch15 --display-name "Ch15 Agents"` |

## 2. API Key Issues

| Symptom | Root Cause | Resolution |
|---|---|---|
| `getpass()` hangs in Jupyter | Some environments don't support interactive input | Handled: code catches `EOFError`, falls back to Simulation Mode |
| Key set but still Simulation Mode | `.env` not in notebook directory | Ensure `.env` is co-located with notebook. Alt: `export OPENAI_API_KEY=sk-...` before launching Jupyter |
| `openai.RateLimitError` in Live Mode | Quota exceeded | `@graceful_fallback` catches this automatically → continues with MockLLM |
| `openai.AuthenticationError` | Invalid/expired key | Check at https://platform.openai.com/api-keys. Update `.env`. Restart kernel. |
| All outputs show `[MOCK]` with valid key | `SIMULATION_MODE` set before key loaded | `.env` must exist before Cell 0. If key set after, restart kernel. |

## 3. Platform-Specific

| Platform | Issue | Workaround |
|---|---|---|
| **Windows** | ANSI colors don't render in `cmd.exe` | Use Windows Terminal, VSCode, or add `colorama`. Jupyter works regardless. |
| **Google Colab** | No local `.env` support | Use Colab Secrets manager or `getpass` (Tier 3). Colab supports ANSI natively. |
| **Docker** | `getpass` fails (non-interactive) | Set key as env var: `docker run -e OPENAI_API_KEY=sk-... ...` or accept Simulation Mode. |
| **Python 3.13+** | `numpy==1.26.4` may lack wheels | Use `numpy>=2.0.0` or stay on Python 3.12. Notebook's numpy usage is version-agnostic. |

## 4. "Runs But Looks Wrong"

| Observation | Likely Cause | Fix |
|---|---|---|
| BKT mastery never increases | `p_transit` too low or `p_guess` too high | Check defaults: `p_transit=0.1`, `p_slip=0.05`, `p_guess=0.2` |
| Planner always returns same objectives | `update_mastery()` not called after BKT update | Ensure shared `StudentModel` instance, updated after each interaction |
| Consensus never converges | Tolerance too tight for mock responses | Mock responses converge at `tolerance=0.5`. For real LLM, increase `max_rounds` or `tolerance` |
| Placement test uses all 15 items | `se_threshold` too low | Default `0.3` works with provided bank. Custom items need `a ≥ 1.0` |

## 5. Debug Priority Order

When something goes wrong, check in this order:

1. **Environment** — Is the virtual environment activated? Correct Python version (≥3.10)?
2. **Dependencies** — `pip list | grep openai` shows `1.40.0`? All packages installed?
3. **API Key** — `.env` in correct directory? Key valid and not expired?
4. **Code Logic** — Restart kernel, run all cells top-to-bottom. Check cell execution order.

## 6. Getting Help

- Check inline notebook error cells — they include contextual troubleshooting hints
- Review the `@graceful_fallback` logs (Red `[HANDLED ERROR]` messages) for specific failure details
- Simulation Mode is always available as a safe fallback — no API key required
