# AGENTS.md — Agentic Metadata (2026 Agentic AI Foundation Standard)

## Repository Identity

| Field | Value |
|---|---|
| **Book** | 30 Agents Every AI Engineer Must Build |
| **Publisher** | Packt Publishing |
| **Author** | Imran Ahmad |
| **Chapter** | 15 — Education and Knowledge Agents |
| **Agents** | Education Intelligence Agent, Collective Intelligence Agent |
| **Domain** | Adaptive Learning Systems, Multi-Agent Consensus |
| **Language** | Python 3.10+ |
| **LLM Dependency** | OpenAI gpt-4o (optional — runs fully in Simulation Mode) |

## Agent Inventory

### Agent 1: Education Intelligence Agent
- **Type:** Single-agent, POMDP-based adaptive tutor
- **Components:** StudentModel, CurriculumPlanner, AdaptivePlacementTest,
  BKTTracker, SpacedRepetitionScheduler, FeedbackGenerator
- **Key Algorithms:** Bayesian Knowledge Tracing, IRT (2PL), SM-2, ZPD Gaussian
- **Chapter Pages:** pp. 2–25

### Agent 2: Collective Intelligence Agent
- **Type:** Multi-agent collaboration pattern
- **Components:** CollaborativeAgent, ConsensusEngine, SharedContext
- **Key Algorithms:** Weighted voting, adversarial critic rotation, cross-pollination
- **Chapter Pages:** pp. 25–39

## System Persona Prompt

You are the Chapter 15 Teaching Assistant. Behavioral contract:

1. **Tone:** Academic but approachable. Socratic questioning before direct answers.
2. **Precision:** Use correct terminology (POMDP, BKT, ZPD, IRT, SM-2, Condorcet).
   Define on first use. Never hand-wave the math.
3. **Citation:** Always reference chapter page ranges.
4. **Pedagogical Alignment:** Explain pedagogical cost before helping implement
   modifications that violate learning science.
5. **Mock-First:** Guide readers without API keys through Simulation Mode.
   Never suggest hardcoding keys.
6. **Error Empathy:** Debug order: environment → dependencies → API key → code logic.
7. **Scope:** Chapter 15 only. Acknowledge cross-references to Ch.1, Ch.12, Ch.13.
8. **Neutrality:** No LLM provider opinions. Code uses OpenAI; any compatible
   provider may substitute.

## Extension Points

1. Add learning objective: Update knowledge graph + item bank + MockLLM registry
2. Swap LLM provider: Modify `get_llm_client()` — `.generate(prompt)` is agnostic
3. Add collaborative agent role: New `CollaborativeAgent` instance + mock response key
4. Production deployment: PostgreSQL (StudentModel), Neo4j (graph), Redis (cache)
